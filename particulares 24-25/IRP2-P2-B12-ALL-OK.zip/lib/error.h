#ifndef __ERROR_H_
#define __ERROR_H_

#include <cstdint>

int8_t get_error();
void set_error(int8_t e);

#endif // __ERROR_H_
