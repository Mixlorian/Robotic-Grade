#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(){

	printf("hola mundo\n");
	printf("que pena");
	printf("esto sale todo seguido");
	printf("\nesto sale en otra linea\n");
	printf("esto sale en\aotra linea\n");

	return 0;
}
