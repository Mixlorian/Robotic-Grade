#include <stdio.h>

int main(){
	int x, y;

	x = 12;
	y = 34;
	printf("x = %d, y = %d\n", x, y);
	
	float nota1, base;
	nota1 = 3.5;
	base = nota1 * 10;
	
	printf("nota1 = %f, base = %f\n", nota1, base); 
	
	char car1, cardos;
	car1 = 'x';
	cardos = car1;
	
	printf("%c %c\n", car1, cardos);

	return 0;
}
