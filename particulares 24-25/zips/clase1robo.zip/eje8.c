/*
Realiza un programa que pida una cantidad en centimos y muestre por
pantalla con cuantas monedas de
	1 euros
	50 centimos
	5 centimos
	1 centimo
podemos construir dicha cantidad. Minimizando el numero total de monedas
*/

#include <stdio.h>

int main(){
	int cantidad, m1e, m50, m5, m1;
	
	printf("Introduce la cantidad a cambiar: ");
	scanf("%d", &cantidad);
	
	// COMPLETA EL CODIGO CON TODOS LOS CALCULOS.
	m1e = cantidad / 100;
	
	// COMPLETA EL CODIGO PARA IMPRIMIR POR PANTALLA LA
	// CANTIDAD DE TODAS LAS MONEDAS.
	
	
	return 0;
}
