#include <stdio.h>

#define KNOMBRE_OBRA 30
#define KNOMBRE_CREADOR 40
typedef char TNombreObra [KNOMBRE_OBRA + 1];
typedef char TNombreCreador [KNOMBRE_CREADOR + 1];
typedef struct{
	int dia, mes, anyo;
}TFecha;
typedef struct{
	int id;
	TNombreObra nombreObra;
	TNombreCreador nombreCreador;
	TFecha adquisicion;
	int anyoCreacionObra;
	int precio;
}TObra;

#define KNOMBRE_EMPLEADO 50
#define KID_LABORAL 10
#define KMAX_OBRAS_CARGO 10
typedef char TNombreEmpleado [KNOMBRE_EMPLEADO + 1]; 	// char []
typedef char TIdLaboral [KID_LABORAL + 1];		// char []
typedef int TObrasCargo [KMAX_OBRAS_CARGO];		// int []

typedef struct{
	TNombreEmpleado nombreEmpleado;
	TIdLaboral idLaboral;
	TObrasCargo obrasCargo; // vector de enteros
	int numObrasCargo; //cantidad de posiciones ocupadas del vetor anterior	
}TEmpleado;

#define KOBRAS_EXPUESTAS 20
#define KNOMBRE_EXPOSICION 50
typedef int TObrasExposicion [KOBRAS_EXPUESTAS];
typedef char TNombreExposicion [KNOMBRE_EXPOSICION + 1];
typedef struct{
	TObrasExposicion obras;
	int numExpuestas;
	int aforo_personas;
	TNombreExposicion nombre;
	TFecha inicio, fin;
}TSalaExposicion;

#define KNOMBRE_MUSEO 30
#define KNOMBRE_DIRECTOR 50
#define KEXPOSICIONES_SIMULTANEAS 5
#define KEMPLEADOS_MUSEO 50
#define KOBRAS_MUSEO 500
typedef char TNombreMuseo [KNOMBRE_MUSEO + 1];
typedef char TNombreDirector [KNOMBRE_DIRECTO + 1];
typedef TEmpleado TEmpleados [KEMPLEADOS_MUSEO];
typedef TObra TObras [KOBRAS_MUSEO];
typedef TSalaExposicion TSalasExposicion [KEXPOSICIONES_SIMULTANEAS];

typedef struct{
	TNombreMuseo nombreMuseo;
	int anyoInaguracion;
	TNombreDirector nombreDirector;
	TEmpleados empleados;
	int numEmpleados;
	TObras obras;
	int numObras;
	TSalasExposicion exposiciones;
	int numExposiciones;
};

int main(){
	return 0;
}

int main(){


	return 0;
}
