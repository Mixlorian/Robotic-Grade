#include <stdio.h>

#define KNOMBRE_CHEF 50
#define KNOMBRE_PLATO 50
typedef char TNombreChef[KNOMBRE_CHEF + 1];
typedef char TNombrePlato[KNOMBRE_PLATO + 1];
typedef struct{
	int id;
	TNombreChef nombre;
	TNombrePlato especial;
}TChef;
#define KCATEGORIA 30
typedef char TCategoria [KCATEGORIA + 1];
typedef struct{
	TNombrePlato nombre;
	TCategoria categoria;
	int tiempoEstimado;
}TPlato;
typedef struct{
	int idChef;
	TNombrePlato platoPreparado;
	int puntos;
}TRonda;
#define KPLATOS 30
#define KCHEFS 50
#define KRONDAS 100
typedef TPlato TListaPlatos [KPLATOS];
typedef TRonda TListaRondas [KRONDAS];
typedef TChef TListaChefs[KCHEFS];
typedef struct{
	TListaPlatos platos;
	int numPlatos;
	TListaRondas rondas;
	int numRondas;
	TListaChefs chefs;
	int numChefs;
}TConcurso;
int main(){
}
