#include <stdio.h>
#include <stdbool.h>

#define KHABITACIONES 300
#define KTIPOHABITACION 50

typedef char TTipoHabitacion [KTIPOHABITACION];
typedef struct{
	int id;
	TTipoHabitacion tipo;
	bool ocupada;
	int tarifaNoche;
}THabitacion;

#define KNOMBREHUESPED 50
#define KNUMEROIDENTIFICACION 10
typedef char TNombreHuesped [KNOMBREHUESPED + 1];
typedef char TNumeroIdentificacion [KNUMEROIDENTIFICACION + 1];
typedef struct{
	int dia, mes, anyo;
}TFecha;

typedef struct{
	TNombreHuesped nombre;
	TNumeroIdentificacion identificacion;
	TFecha checkin,checkout;
	int numeroHabitacion;
}THuesped;

typedef struct{
	
}TEmpleados;



