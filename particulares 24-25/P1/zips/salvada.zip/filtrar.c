#include <stdio.h>


// recibe dos nombre de fichero
// 	argv[1] => fichero origen.
//	argv[2] => fichero destino.
//	argv[3] => longitud maxima de linea
// origen.txt (maximo numero de caracteres por linea será 100)
/*
la casa es grande
una buena casa te compraste broh
por dentro todos somos iguales
viva la academia b12.es :)
*/
// guarda en el fichero destino todas las lineas que tengan
// longitud menor a la longitud maxima.

int main(int argc, char *argv[]){
	

	return 0;
}
