#include "imperialship.h"

namespace P4{

ImperialShip::ImperialShip(char symbol, uint energy):Ship(symbol, energy){

}

}
