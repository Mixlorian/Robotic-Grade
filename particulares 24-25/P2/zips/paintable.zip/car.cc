#include "car.h"

namespace C4{

Car::Car(int m):MotorVehicle(m, 4){
	cout << "Building a fucking car" << endl;
}


Car::~Car(){
	cout << "Destroying your ass in my car with my cock" << endl;
}

}
