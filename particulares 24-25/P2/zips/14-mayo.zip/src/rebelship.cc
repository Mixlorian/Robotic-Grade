#include "rebelship.h"

namespace P4{

// invocamos al constructor param
RebelShip::RebelShip(char symbol, uint energy):Ship(symbol, energy){
}


}
