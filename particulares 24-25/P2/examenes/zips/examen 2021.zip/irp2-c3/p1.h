// -*- mode: c++ -*-

#ifndef P1_H
#define P1_H

#include <cstdint>

namespace C3 {

  uint32_t ncuts(uint32_t n);

}  // C3

#endif /* P1_H */
